import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ControlPanel } from './components/ControlPanel';
import { useSpeechSynthesis } from './hooks/useSpeechSynthesis';

const App: React.FC = () => {
    const [text] = useState<string>("A tecnologia nos permite transformar palavras escritas em som, criando uma ponte entre o texto e a audição. Explore as diferentes vozes e configurações para encontrar o tom perfeito para a sua leitura.");
    const {
        voices,
        speak,
        pause,
        resume,
        cancel,
        status,
        selectedVoice,
        setSelectedVoice,
        pitch,
        setPitch,
        rate,
        setRate
    } = useSpeechSynthesis();

    const handleSpeak = useCallback(() => {
        if (text.trim() === '') return;

        if (status === 'paused') {
            resume();
        } else {
            speak(text);
        }
    }, [text, status, speak, resume]);

    const handlePause = useCallback(() => {
        pause();
    }, [pause]);

    const handleStop = useCallback(() => {
        cancel();
    }, [cancel]);

    return (
        <div className="min-h-screen bg-slate-900 text-white font-sans flex flex-col">
            <Header />
            <main className="flex-grow flex flex-col items-center justify-center p-4">
                <div className="w-full max-w-4xl mx-auto bg-slate-800 rounded-2xl shadow-2xl shadow-blue-500/10 overflow-hidden ring-1 ring-slate-700">
                    <div className="p-6 sm:p-8 space-y-6">
                        <h2 className="text-xl sm:text-2xl font-bold text-blue-400">
                            Texto para Sintetizar
                        </h2>
                        <textarea
                            value={text}
                            readOnly
                            className="w-full h-48 p-4 bg-slate-900 border-2 border-slate-700 rounded-lg transition-all duration-300 resize-none text-slate-200 cursor-default"
                        />
                    </div>
                    <ControlPanel
                        voices={voices}
                        selectedVoice={selectedVoice}
                        onVoiceChange={setSelectedVoice}
                        pitch={pitch}
                        onPitchChange={setPitch}
                        rate={rate}
                        onRateChange={setRate}
                        status={status}
                        onSpeak={handleSpeak}
                        onPause={handlePause}
                        onStop={handleStop}
                    />
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default App;