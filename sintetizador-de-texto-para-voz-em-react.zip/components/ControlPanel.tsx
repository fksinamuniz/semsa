import React from 'react';
import type { SpeechStatus } from '../hooks/useSpeechSynthesis';
import { PlayIcon, PauseIcon, StopIcon, VoiceIcon, PitchIcon, RateIcon } from './Icons';

interface ControlPanelProps {
    voices: SpeechSynthesisVoice[];
    selectedVoice: SpeechSynthesisVoice | null;
    onVoiceChange: (voice: SpeechSynthesisVoice | null) => void;
    pitch: number;
    onPitchChange: (value: number) => void;
    rate: number;
    onRateChange: (value: number) => void;
    status: SpeechStatus;
    onSpeak: () => void;
    onPause: () => void;
    onStop: () => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
    voices,
    selectedVoice,
    onVoiceChange,
    pitch,
    onPitchChange,
    rate,
    onRateChange,
    status,
    onSpeak,
    onPause,
    onStop,
}) => {
    const handleVoiceSelect = (event: React.ChangeEvent<HTMLSelectElement>) => {
        const selected = voices.find(v => v.name === event.target.value);
        onVoiceChange(selected || null);
    };

    const isSpeaking = status === 'speaking';
    const isPaused = status === 'paused';
    
    return (
        <div className="bg-slate-800/50 p-6 sm:p-8 border-t border-slate-700">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                {/* Voice Selection */}
                <div className="space-y-2">
                    <label htmlFor="voice-select" className="flex items-center text-sm font-medium text-slate-300">
                        <VoiceIcon /> <span className="ml-2">Voz</span>
                    </label>
                    <select
                        id="voice-select"
                        value={selectedVoice?.name || ''}
                        onChange={handleVoiceSelect}
                        disabled={voices.length === 0}
                        className="w-full bg-slate-700 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                    >
                        {voices.map(voice => (
                            <option key={voice.name} value={voice.name}>
                                {voice.name} ({voice.lang})
                            </option>
                        ))}
                    </select>
                </div>

                {/* Pitch Slider */}
                <div className="space-y-2">
                    <label htmlFor="pitch" className="flex items-center text-sm font-medium text-slate-300">
                       <PitchIcon /> <span className="ml-2">Tom: {pitch.toFixed(1)}</span>
                    </label>
                    <input
                        id="pitch"
                        type="range"
                        min="0"
                        max="2"
                        step="0.1"
                        value={pitch}
                        onChange={(e) => onPitchChange(parseFloat(e.target.value))}
                        className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                </div>

                {/* Rate Slider */}
                <div className="space-y-2">
                    <label htmlFor="rate" className="flex items-center text-sm font-medium text-slate-300">
                        <RateIcon /> <span className="ml-2">Velocidade: {rate.toFixed(1)}</span>
                    </label>
                    <input
                        id="rate"
                        type="range"
                        min="0.1"
                        max="2"
                        step="0.1"
                        value={rate}
                        onChange={(e) => onRateChange(parseFloat(e.target.value))}
                        className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-center space-x-4">
                <button
                    onClick={onSpeak}
                    disabled={isSpeaking}
                    className="flex items-center justify-center px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 disabled:cursor-not-allowed text-white font-semibold rounded-lg shadow-md transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-blue-500"
                >
                    <PlayIcon />
                    <span className="ml-2">{isPaused ? 'Retomar' : 'Falar'}</span>
                </button>
                <button
                    onClick={onPause}
                    disabled={!isSpeaking}
                    className="flex items-center justify-center px-6 py-3 bg-yellow-500 hover:bg-yellow-600 disabled:bg-yellow-700 disabled:cursor-not-allowed text-white font-semibold rounded-lg shadow-md transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-yellow-400"
                >
                    <PauseIcon />
                    <span className="ml-2">Pausar</span>
                </button>
                <button
                    onClick={onStop}
                    disabled={status === 'idle' || status === 'ended'}
                    className="flex items-center justify-center px-6 py-3 bg-red-600 hover:bg-red-700 disabled:bg-red-800 disabled:cursor-not-allowed text-white font-semibold rounded-lg shadow-md transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-red-500"
                >
                    <StopIcon />
                    <span className="ml-2">Parar</span>
                </button>
            </div>
        </div>
    );
};