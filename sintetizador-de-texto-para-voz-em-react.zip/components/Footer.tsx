import React from 'react';

export const Footer: React.FC = () => {
    return (
        <footer className="bg-slate-800/50 border-t border-slate-700 py-4 mt-8">
            <div className="container mx-auto px-4 text-center text-slate-400 text-sm">
                <p>&copy; {new Date().getFullYear()} TTS com IA. Todos os direitos reservados.</p>
                <p>Construído com React, TypeScript e Tailwind CSS.</p>
            </div>
        </footer>
    );
};