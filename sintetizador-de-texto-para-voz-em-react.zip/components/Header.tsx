import React from 'react';

const SpeakerIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
    </svg>
);

export const Header: React.FC = () => {
    return (
        <header className="bg-slate-800/50 backdrop-blur-sm border-b border-slate-700 shadow-md sticky top-0 z-10">
            <div className="container mx-auto px-4 py-3 flex items-center justify-center">
                <SpeakerIcon />
                <h1 className="ml-3 text-2xl font-bold tracking-tight text-slate-100">
                    Sintetizador de Texto para Voz
                </h1>
            </div>
        </header>
    );
};