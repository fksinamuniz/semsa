import { useState, useEffect, useCallback } from 'react';

export type SpeechStatus = 'idle' | 'speaking' | 'paused' | 'ended';

export const useSpeechSynthesis = () => {
    const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
    const [status, setStatus] = useState<SpeechStatus>('idle');
    const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
    const [pitch, setPitch] = useState<number>(1);
    const [rate, setRate] = useState<number>(0.9);
    
    const populateVoiceList = useCallback(() => {
        const newVoices = window.speechSynthesis.getVoices();
        setVoices(newVoices);
        if (!selectedVoice && newVoices.length > 0) {
            // Prefer a default Portuguese voice if available
            const defaultVoice = newVoices.find(voice => voice.lang.includes('pt-BR')) || newVoices[0];
            setSelectedVoice(defaultVoice);
        }
    }, [selectedVoice]);

    useEffect(() => {
        populateVoiceList();
        if (window.speechSynthesis.onvoiceschanged !== undefined) {
            window.speechSynthesis.onvoiceschanged = populateVoiceList;
        }
    }, [populateVoiceList]);

    const speak = useCallback((text: string) => {
        if (!window.speechSynthesis || !text) return;
        
        // Cancel any previous speech
        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        
        utterance.onstart = () => setStatus('speaking');
        utterance.onpause = () => setStatus('paused');
        utterance.onresume = () => setStatus('speaking');
        utterance.onend = () => setStatus('ended');
        // A small timeout to reset to idle after ending, for better UX
        utterance.addEventListener('end', () => {
            setTimeout(() => setStatus('idle'), 200);
        });

        if (selectedVoice) {
            utterance.voice = selectedVoice;
        }
        utterance.pitch = pitch;
        utterance.rate = rate;

        window.speechSynthesis.speak(utterance);
    }, [selectedVoice, pitch, rate]);

    const pause = useCallback(() => {
        if (window.speechSynthesis) {
            window.speechSynthesis.pause();
        }
    }, []);

    const resume = useCallback(() => {
        if (window.speechSynthesis) {
            window.speechSynthesis.resume();
        }
    }, []);

    const cancel = useCallback(() => {
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
            setStatus('idle');
        }
    }, []);

    return {
        voices,
        speak,
        pause,
        resume,
        cancel,
        status,
        selectedVoice,
        setSelectedVoice,
        pitch,
        setPitch,
        rate,
        setRate,
    };
};